
import Dashboard from "@/pages/Dashboard";

const Index = () => {
  return <Dashboard />;
};

export default Index;
