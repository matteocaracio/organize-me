
import MarketData from "./market/MarketData";

export default MarketData;
