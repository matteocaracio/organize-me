
// Importar as funções do hook use-toast
import { useToast, toast } from "@/hooks/use-toast";

// Reexportar as funções
export { useToast, toast };
